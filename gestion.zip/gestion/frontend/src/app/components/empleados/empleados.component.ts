import { Component, OnInit } from '@angular/core';
import { EmpleadoService } from "../../services/empleado.service";
import { NgForm } from '@angular/forms';
import { Empleado } from '../../models/empleado';

declare var M: any;

@Component({
  selector: 'app-empleados',
  templateUrl: './empleados.component.html',
  styleUrls: ['./empleados.component.scss'],
  providers: [EmpleadoService]
})
export class EmpleadosComponent implements OnInit {
  cedulaEditable = true; /*variable que se usa en el metodo verEmpleado*/

  constructor(public empleadoService: EmpleadoService) { }

  ngOnInit(): void {
    this.obtenerEmpleados(); 
  }

  agregarEmpleado(form?: NgForm) {
    this.empleadoService.PostEmpleado(form?.value)
      .subscribe(res => {
        this.resetForm(form);
        M.toast({html: 'Guardado satisfactoriamente'});
      });
  }

  verEmpleado(cedula: number) {
    this.empleadoService.getEmpleado(cedula)/*ver empleado por cedula*/
      .subscribe(res => {
        this.empleadoService.selectedEmpleado = res as Empleado;
        this.cedulaEditable = false; /*aqui se bloquea el campo cedula despues de darle visualizar*/
      });
  }
 /*actualizarEmpleado(form?: NgForm) {
    if (form && form.value) {
      console.log('Datos a actualizar:', form.value);
      const empleado = this.empleadoService.selectedEmpleado?._id;
      if (empleado) {
        console.log('datos a enviar',empleado,form.value);
        this.empleadoService.putEmpleado(empleado, form.value)
          .subscribe(
            res => {
              this.resetForm(form);
              M.toast({ html: 'Actualizado satisfactoriamente' });
              
            },
            error => {
              console.error('Error al actualizar:', error);
              if (error.error && error.error.message) {
                M.toast({ html: `Error: ${error.error.message}` });
              }
            }
          );
      }
    }
  }*/

  actualizarEmpleado(form?: NgForm) {
    if (form && form.value) {
      console.log('Datos a actualizar:', form.value);
      const empleado = this.empleadoService.selectedEmpleado?.cedula;
      if (empleado) {
        console.log('datos a enviar', empleado, form.value);
        this.empleadoService.putEmpleado(empleado, form.value)
          .subscribe(
            (res: any) => {
              this.resetForm(form);
              M.toast({ html: 'Actualizado satisfactoriamente' });
            },
            (error: any) => {
              console.error('Error al actualizar:', error);
              if (error.error && error.error.message) {
                M.toast({ html: `Error: ${error.error.message}` });
              }
            }
          );
      }
    }
  }
 
 eliminarEmpleado(cedula: number) {// se utiliza string o number
    if (confirm('¿Estás seguro de eliminar este empleado?')) {
      this.empleadoService.deleteEmpleado(cedula)
        .subscribe(
          res => {
            M.toast({html: 'Eliminado satisfactoriamente'});
            this.resetForm(); // Limpiar el formulario después de eliminar
            this.obtenerEmpleados();
          },
          error => {
            console.error('Error al intentar eliminar empleado:', error);
          }
        );
    }
  }

  /*eliminarEmpleado(id: string) {
    if (confirm('¿Estás seguro de eliminar este empleado?')) {
        this.empleadoService.deleteEmpleado(id)
            .subscribe(
                res => {
                    M.toast({ html: 'Eliminado satisfactoriamente' });
                    this.resetForm(); // Limpiar el formulario después de eliminar
                    this.obtenerEmpleados();
                },
                error => {
                    console.error('Error al intentar eliminar empleado:', error);
                    // Agrega un mensaje de error en tu interfaz de usuario o imprímelo en la consola del navegador.
                    M.toast({ html: `Error al intentar eliminar empleado: ${error.message}` });
                }
            );
    }
}*/


  obtenerEmpleados() {
    this.empleadoService.getEmpleados()
      .subscribe(res => {
        this.empleadoService.empleados = res as Empleado[];
      });
  }

  
 
  resetForm(form?: NgForm) {
    if (form) {
      form.reset();
    }
    this.empleadoService.selectedEmpleado = new Empleado();
  }
}