import { Component } from '@angular/core';



@Component({
  selector: 'app-productos',
  templateUrl: './productos.component.html',
  styleUrl: './productos.component.scss'
})
export class ProductosComponent {
  
  // Lista de carros (productos)
  carros = [
    { modelo: 'Lamborghini Huracán', anio: 2022, precio: 2000000, imagen: 'assets/lamborghini.jpg' },
    { modelo: 'Lamborghini Aventador', anio: 2023, precio: 3000000, imagen: 'assets/lamborghini2.jpg' },
    // Agrega más carros según sea necesario
  ];


  formatearPrecio(precio: number): string {
    const formatoPrecio = new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD'
    });
    return formatoPrecio.format(precio);
  }


}


