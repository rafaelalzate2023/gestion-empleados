import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Empleado } from '../models/empleado';// se importa el modelo tipo json
import { catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EmpleadoService {//exportamos estos metodos para que sean utilizados por otro archivo

  selectedEmpleado: Empleado;
  empleados : Empleado[];
  readonly URL_API = 'http://localhost:3000/api/empleados';//ruta para conectar a la api

  constructor(private http: HttpClient) {
    this.selectedEmpleado = new Empleado();
     this.empleados = [];
   }
//metodos
getEmpleados() {
  return this.http.get(this.URL_API);
}

/*getEmpleado(id: string) {
  return this.http.get(this.URL_API + '/' + id);
}*/
getEmpleado(cedula: number) {
  return this.http.get(this.URL_API + '/cedula/' + cedula);
}
  PostEmpleado(Empleado:Empleado){
    return this.http.post(this.URL_API, Empleado);
  }

 
  /*putEmpleado(cedula: string, empleado: Empleado) {//para hacer po id se coloc _id
    return this.http.put(this.URL_API + '/cedula/' + cedula, empleado)
    /*return this.http.put(this.URL_API + '/' + _id, empleado)/*aqui se usa concatenacion de cadenas*/
    /*return this.http.put(`${this.URL_API}/${_id}`, empleado)*//*comillas invertidas y plantillas decadena*/
        //.pipe(
            //catchError(error => {
               // console.error('Error al actualizar empleado desde el servicio:', error);
                //throw error;
           // })
       // );
//}

putEmpleado(cedula: number, empleado: Empleado) {
  return this.http.put(`${this.URL_API}/cedula/${cedula}`, empleado)
    .pipe(
      catchError(error => {
        console.error('Error al actualizar empleado desde el servicio:', error);
        throw error;
      })
    );
}

  /*deleteEmpleado(_id: string) {// si se quiere por id se agrega _id
    
    return this.http.delete(this.URL_API + '/' + _id);
  }*/
  deleteEmpleado(cedula: number) {//se utiliza  string
    return this.http.delete(`${this.URL_API}/cedula/${cedula}`);
  }
}

