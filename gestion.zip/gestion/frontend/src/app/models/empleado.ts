export class Empleado {
    constructor(_id = "", cedula=0, name = "", position = "", office = "", salary = 0) {
        this._id = _id;
        this.cedula=cedula;
        this.name = name;
        this.position = position;
        this.office = office;
        this.salary = salary;
      }
      //se define el tipo de atributo  String  y number
    _id: string; // Sub guión id porque los datos van a venir de MOngodb
    cedula:number;
    name: string;
    position: string;
    office: string;
    salary: number;

}


//Angular usa este modelo para estructurar y manipular datos en la aplicacion